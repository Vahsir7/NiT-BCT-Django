from django.contrib import admin
from .models import Applicants
admin.site.register(Applicants)
# Register your models here.
